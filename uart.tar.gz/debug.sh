arm-unknown-linux-gnueabi-gdb -x "gdb.cmds" uart.bin
